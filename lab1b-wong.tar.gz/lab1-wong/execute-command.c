// UCLA CS 111 Lab 1 command execution
//ALBERT WONG
#include "command.h"
#include "command-internals.h"


#include <error.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>

/* FIXME: You may need to add #include directives, macro definitions,
   static function definitions, etc.  */
/*
void  printStr(char* c)
{
	int length = strlen(c);
	int i;
	for(i = 0; i < length; i++)
	{
		printf("%c", c[i]);
	}
	printf("\nlength: %d\n", length);
	printf("end printString\n");
}*/

int
command_status (command_t c)
{
  return c->status;
}
/*
pid_t forkWrap()
{
	pid_t pid = fork();
	
	if(pid < 0)
	{
		fprintf(stderr, "Fork failed\n");
		//exit(1);
	}

	return pid;
}

int execvpWrap(const char* file, char *const argv[])
{
	int suc = execvp(file, argv);
	if(suc < 0)
	{
		fprintf(stderr, "execution failed\n");
		//exit(1);
	}
	return suc;
}
*/


int isExec(char* c)
{
	if(c[0] == 'e' && c[1] == 'x' && c[2] == 'e' && c[3] == 'c')
	{
		return 1;
	}
	return 0;
}



void execSimpleCommand(command_t c)
{
	//printf("exec simple command\n");
	pid_t pid = fork();
	if(pid < 0)
	{
		//c->status = 1;
		error(1, 0, "error when forking\n");
		return;
	}
	if(pid == 0) // child process
	{
		//printf("simple child\n");
		if(c->output != NULL)
		{
			//printf("output not null\n");
			char* output = c->output;
			int fout = open(output, O_WRONLY | O_CREAT | O_TRUNC, 0666);
			if(fout < 0)
			{
				error(1, 0, "error when opening file for output\n");
			}
			else
			{
				//printf("open file successful\n");
				if(dup2(fout, 1) < 0)
				{
					error(1, 0, "error in dup2\n");
				}
				
			}
			close(fout);
		}
		
		if(c->input != NULL)
		{
			char* input = c->input;
			int fin = open(input, O_RDONLY, 0666);
			if(fin < 0)
			{
				error(1, 0, "error when opening file for input\n");
			}
			else
			{
				if(dup2(fin, 0) < 0)
				{
					error(1, 0, "error in dup2\n");
				}
				close(fin);
			}
			
		}
		//printf("WTF");
		//printf("a\n");
		char*arg1;
		char** arg2;
		
		  if(!isExec(c->u.word[0]))
        {
            arg1 = c->u.word[0];
            arg2 = c->u.word;   
        }
        else
        {
            arg1 = c->u.word[1];
            arg2 = c->u.word + 1;
        }
		
		/*	arg1 = c->u.word[0];
			arg2 = c->u.word;	*/
			//printStr(arg1);
			//printf("numWords: %d\n", c->numWords);
			//printf("before exec\n");
		if(execvp(arg1, arg2) < 0)
		{
		//	c->status = 
			error(1, 0, "Error in execution of simple command\n");
			//return;
		}
		//printf("after exec\n");
		//exit(0);

		 /* if(execvp(c->u.word[0],c->u.word)<0)
			  printf("error");
                exit(c->status);*/
	}
	else // parent process
	{
		
		int status;
		waitpid(pid, &status, 0);
		//printf("simple parent\n");

		c->status = WEXITSTATUS(status);
		//printf("status: %d\n", c->status);
	}
	//printf("end exec simple command\n");
}

/*if(!isExec(c->u.word[0]))
		{
			arg1 = c->u.word[0];
			arg2 = c->u.word;	
		}
		else
		{
			arg1 = c->u.word[1];
			arg2 = c->u.word + 1;
		}*/
/*
void executeSubshellCommand(command_t c)
{

}*/


void execPipe(command_t c)
{
	int pipefd[2];
	command_t left = c->u.command[0];
	command_t right = c->u.command[1];

	if(pipe(pipefd) < 0)
	{
		error(1, 0, "error when trying to pipe\n");
		return;
	}

	pid_t pid1 = fork();
	
	if(pid1 < 0) // fork error
	{
		error(1, 0, "error when forking\n");
	}

	else if(pid1 == 0)
	{
		//printf("child1\n");
		
		close(pipefd[0]);
		if(dup2(pipefd[1], 1) < 0)
		{
			error(1, 0, "error in pipe  dup2\n");
			exit(1);
				// error
		}

		execute_command(left, 0);
		if(left->status != 0)
		{
			error(1, 0, "error in execution of left pipe");
		}
		exit(0);
		
	}
	

	pid_t pid2 = fork();

	if(pid2 < 0) // fork error
	{
		error(1, 0, "error when forking\n");
		// error
	}
	else if(pid2 == 0) // child process 
		// execute right side of pipe
	{
		// wait for child to finish
			
		//check exit status of left pipe command
		close(pipefd[1]);
		if(dup2(pipefd[0], 0) < 0)
		{
			error(1, 0, "error in pipe dup2\n");
			exit(1);
			// error
		}
		//close(pipefd[0]);


	//	printf("child2\n");
		
		execute_command(right, 0);
		if(right->status != 0)
		{
			error(1, 0, "error in execution of right pipe");

		}
		exit(0);
	}
	
	int status1, status2;
		
	close(pipefd[0]);
	close(pipefd[1]);
	waitpid(pid1, &status1, 0);
	waitpid(pid2, &status2, 0);
	//printf("status1: %d\n", WEXITSTATUS(status1));
	//printf("status2: %d\n", WEXITSTATUS(status2));
	c->status = WEXITSTATUS(status2);
	if(WEXITSTATUS(status2) == 0 &&  WEXITSTATUS(status1) != 0)
	{
		c->status = WEXITSTATUS(status1);
	}
	//printf("c->status: %d\n", c->status);

	

}
/*else
	{
		int status;
		close(pipefd[0]);
		close(pipefd[1]);
		waitpid(pid2, &status, 0); 
		printf("status: %d" , status);
		c->status = status;
		return;
	}*/

void printCommType(enum command_type command)
{
	switch(command)
		{
			case AND_COMMAND: printf("AND_COMMAND\n"); break;
			case SEQUENCE_COMMAND: printf("SEQUENCE_COMMAND\n"); break;
			case OR_COMMAND: printf("OR_COMMAND\n"); break;
			case PIPE_COMMAND: printf("PIPE_COMMAND\n"); break;
			case SIMPLE_COMMAND: printf("SIMPLE_COMMAND\n"); //printf("commList[i].numWords: %d\n", commList[i].numWords);
									 //printWords(commList[i].u.word, commList[i].numWords); break;
				break;
			case OPEN_PAREN: printf("OPEN_PAREN\n"); break;
			case CLOSED_PAREN: printf("CLOSED_PAREN\n"); break;
			case LEFT_REDIRECT: printf("LEFT_REDIRECT\n"); break;
			case RIGHT_REDIRECT: printf("RIGHT_REDIRECT\n"); break;
			case NEW_LINE: printf("NEW_LINE\n"); break;
			default: break;
		}
}

void execOperatorCommand(command_t c)
{
	command_t left = c->u.command[0];
	command_t right = c->u.command[1];
	switch(c->type)
	{
	case AND_COMMAND:
		
		execute_command(left, 0);
		c->status = left->status;
		if(left->status == 0) // if left command successful, execute right command and save status of right command
		{
			execute_command(right, 0);
			c->status = right->status;
		}
		else // dont execute right command
		{
			c->status = left->status;
		}

		break;
	case OR_COMMAND:
		execute_command(left, 0);
		c->status = left->status;
		if(left->status != 0) // if left command is not successful, execute right command and save status of right command
		{
			execute_command(right, 0);
			c->status = right->status;
		}
		else
		{
			c->status = left->status;
		}
		break;
	case PIPE_COMMAND:
		execPipe(c);
		break;
	case SEQUENCE_COMMAND:
		execute_command(left, 0);
		execute_command(right, 0);
		break;
	default:
		fprintf(stderr, "ERROR: INVALID COMMAND");
		//printCommType(c->type);
	}
}

	void
execute_command (command_t c, int time_travel)
{
  /* FIXME: Replace this with your implementation.  You may need to
     add auxiliary functions and otherwise modify the source code.
     You can also use external functions defined in the GNU C Library.  */
	switch(c->type)
	{
	case SIMPLE_COMMAND:
		execSimpleCommand(c);
		break;
	case SUBSHELL_COMMAND:
		execute_command(c->u.subshell_command, 0);
		c->status = c->u.subshell_command->status;
		break;
	default:
		execOperatorCommand(c);
	


 // error (1, 0, "command execution not yet implemented");
	}
}
